import random
dying_methods = ("will get hit by a car",
          "will die from a hear disease",
          "will die from an accident",
          "your enemy will find and kill you",
          "will die from a stroke",
          "will die from a kidney disease",
          "will die from luver disease",
          "will die from hypertension",
          "will die from parkinson disease",
          "will die from an explosion",
          "will die from drug poisoning",
          "will get killed by a ghost",
          "will get killed by falling from a staircase",
          "will die from an assault from a firearm",
          "will die by burning into ashes",
          "will die by drowning in water",
          "will die by drowning in swimming pool",
          "will die by falling from a ladder",
          "will get killed by a plane crash",
          "will get killed by a flood",
          "will get killed by a tsunami",
          "will get killed by lightening",
          "will die from a drug overdose",
          "will get killed by stray dogs"
          )

x = random.choice(dying_methods)
print(x)

